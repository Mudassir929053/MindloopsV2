<?php

require 'lib/API.php';
require 'lib/Connect.php';
require 'configuration.php';

use Billplz\Minisite\API;
use Billplz\Minisite\Connect;

$Useramount = 0;

if ($_REQUEST['amount'] == 'MXT') {
    $Useramount = 10000;
} elseif ($_REQUEST['amount'] == 'MYZ') {
    $Useramount = 55000;
} elseif ($_REQUEST['amount'] == 'MYT') {
    $Useramount = 100000;
} else {
    // Redirect to package.php if amount is invalid
    header("Location: ../../package.php");
    exit(); // Stop further execution
}


$parameter = array(
    'collection_id' => !empty($collection_id) ? $collection_id : $_REQUEST['collection_id'],
    'email' => isset($_REQUEST['email']) ? $_REQUEST['email'] : '',
    'mobile' => isset($_REQUEST['mobile']) ? $_REQUEST['mobile'] : '',
    'name' => isset($_REQUEST['name']) ? $_REQUEST['name'] : 'No Name',
    'amount' => !empty($amount) ? $amount : $Useramount,
    'callback_url' => $websiteurl . '/callback.php',
    'description' => !empty($description) ? $description : $_REQUEST['description'],
    'userid' => isset($_REQUEST['userid']) ? $_REQUEST['userid'] : 'No Userid',
);

$optional = array(
    'redirect_url' => $websiteurl . '/redirect.php' . '?name=' . urlencode($parameter['name']) . '&mobile=' . urlencode($parameter['mobile']) . '&email=' . urlencode($parameter['email']) . '&reference_1=' . urlencode(isset($_REQUEST['usertype']) ? $_REQUEST['usertype'] : '') . '&reference_2=' . urlencode(isset($_REQUEST['password']) ? $_REQUEST['password'] : ''),
    'reference_1_label' => isset($reference_1_label) ? $reference_1_label : $_REQUEST['reference_1_label'],
    'reference_1' => isset($_REQUEST['usertype']) ? $_REQUEST['usertype'] : '',
    // 'reference_2_label' => isset($reference_2_label) ? $reference_2_label : $_REQUEST['reference_2_label'],
    // 'reference_2' => isset($_REQUEST['mobile']) ? $_REQUEST['mobile'] : '',
    'deliver' => 'false'
);

// var_dump($parameter);
// echo "<br>";
// var_dump($optional);
// exit;
if (empty($parameter['mobile']) && empty($parameter['email'])) {
    $parameter['email'] = 'noreply@billplz.com';
}

if (!filter_var($parameter['email'], FILTER_VALIDATE_EMAIL)) {
    $parameter['email'] = 'noreply@billplz.com';
}

$connect = new Connect($api_key);
$connect->setStaging($is_sandbox);
$billplz = new API($connect);
try {
    list ($rheader, $rbody) = $billplz->toArray($billplz->createBill($parameter, $optional));
    if ($rheader === 200) {
        // Redirect to payment page
        header('Location: ' . $rbody['url']);
        exit();
    } else {
        echo '<pre>'.print_r($rheader, true).'</pre>';
        echo '<pre>'.print_r($rbody, true).'</pre>';
    }
} catch (Exception $e) {
    echo $e->getMessage();
}

?>

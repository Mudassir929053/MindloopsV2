<?php

/**
 * Instruction:
 *
 * 1. Replace the APIKEY with your API Key.
 * 2. Replace the COLLECTION with your Collection ID.
 * 3. Replace the X_SIGNATURE with your X Signature Key
 * 4. Change $is_sandbox = false to $is_sandbox = true for sandbox
 * 5. Replace the http://www.google.com with the full path to the site.
 * 6. Replace the http://www.google.com/success.html with the full path to your success page. *The URL can be overridden later
 * 7. OPTIONAL: Set $amount value.
 * 8. OPTIONAL: Set $fallbackurl if the user are failed to be redirected to the Billplz Payment Page.
 *
 */

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mindloops";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$api_key = 'cd0de0b5-384e-4f29-958f-50e8ec45d301';
$collection_id = '6t7q5e6c6';
$x_signature = 'S-uD3jieg_V4RxFoLO2Wfviw';
$is_sandbox = true;

$websiteurl = 'http://192.168.0.131:5000/subscription/billplz';
$successpath = 'http://192.168.0.131:5000/subscription/billplz/success.php';
//$amount = ''; //Example (RM13.50):
//$amount = '1350';
$fallbackurl = ''; //Example: 
$fallbackurl = 'http://192.168.0.131:5000/payment_error.php';
$description = 'PAYMENT Members Club Subscription';
$reference_1_label = '';
$reference_2_label = ''; 


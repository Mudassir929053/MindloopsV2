
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Payment Success</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <!-- Subscription Card - 1 Month -->
            <div class="col-md-4 mx-auto">
                <div class="card text-dark" style="background-color: #DEEDFF;">
                    <div class="card-body">
                        <img src="../../assets/images/memberclub/payment-successful.png" class="img-fluid pb-md-3" alt="">
                        <h2 class="card-title text-center fw-bold">Payment Successfully</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script>
        // Countdown timer and redirect
        let count = 5; // Countdown from 5 seconds
        let redirectInterval = setInterval(() => {
            count--;
            if (count <= 0) {
                clearInterval(redirectInterval); // Stop the countdown
                window.location.href = '../../membersclub_pt.php';
            } else {
                // Update the text with the countdown
                document.getElementById('redirectMessage').innerText = `Don't click. Page will be redirected soon...${count} seconds`;
            }
        }, 1000); // Update every second
    </script>

    <div class="text-center text-danger mt-3" id="redirectMessage">Don't click. Page will be redirected soon... 5 seconds</div>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
<?php
require 'lib/API.php';
require 'lib/Connect.php';
require 'configuration.php';

use Billplz\Minisite\API;
use Billplz\Minisite\Connect;

// Validate and sanitize input data (not shown here)

$data = Connect::getXSignature($x_signature, 'bill_redirect');
// exit;
$connect = new Connect($api_key);
$connect->setStaging($is_sandbox);
$billplz = new API($connect);
list($rheader, $rbody) = $billplz->toArray($billplz->getBill($data['id']));


// echo "<pre>";
// print_r($rbody);
// echo "</pre>";
// echo $_GET['mobile'];
// echo "<pre>";
// // print_r($rheader);
// echo "</pre>";
// exit;
// Check if $_SESSION['uid'] is set

session_start();
// Now you can access $_SESSION['uid']
$user_id = isset($_SESSION['uid']) ? $_SESSION['uid'] : null;
// echo $user_id;
// exit;

if ($rbody['paid']) {
    // var_dump($rbody);
  
    $type = $_GET['reference_1'];
    if ($type == 'parent') {
        $type = 4;
    } else {
        $type = 2;
    }

    $user_data = array(
        'u_name' => $rbody['reference_1'],
        'u_email' => $rbody['email'],
        'u_contact' => $rbody['mobile'],
        'userid' => $user_id,
        'u_pwd' => $hashed_password,
        'u_type' => $type,
    );

    // Check if connection was successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $subscription_data = array(
        'user_name' => $rbody['name'],
        'user_email' => $user_data['u_email'],
        'transaction_id' => $rbody['id'],
        'amount' => $rbody['amount'] / 100,
        'status' => $rbody['paid'] ? 'paid' : 'unpaid',
        'userid' => $user_id, // Assign 'userid' if available, otherwise null
    );
    
    $stmt = $conn->prepare("INSERT INTO subscription (s_name, s_email, transaction_id, s_amount, s_status, s_start_date, s_end_date, subscriber_id) VALUES (?, ?, ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 MONTH), ?)");
    
    if ($stmt === false) {
        echo "Error: " . $conn->error;
        // exit();
    }
    
    $stmt->bind_param("sssssi", $subscription_data['user_name'], $subscription_data['user_email'], $subscription_data['transaction_id'], $subscription_data['amount'], $subscription_data['status'], $subscription_data['userid']);
    
    // Execute the prepared statement to insert data into subscription table
    if ($stmt->execute()) {
        // Get the last inserted subscription ID
        $subscription_id = $stmt->insert_id;
        $stmt->close();

        // Generate code for the subscription and insert data into tb_scodes table
        $code_data = array(
            'sc_package' => $rbody['reference_1'],
            'sc_count' => 1,
            'sc_sDate' => date('Y-m-d'),
            'sc_eDate' => date('Y-m-d', strtotime('+1 month')),
            'sc_paymentID' => $subscription_id,
            'sc_billCode' =>$rbody['id'],
        );

        $stmt = $conn->prepare("INSERT INTO tb_scodes (sc_package, sc_count, sc_sDate, sc_eDate, sc_paymentID, sc_billCode) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt === false) {
            echo "Error: " . $conn->error;
            // exit();
        }
        $stmt->bind_param("sissss", $code_data['sc_package'], $code_data['sc_count'], $code_data['sc_sDate'], $code_data['sc_eDate'], $code_data['sc_paymentID'], $code_data['sc_billCode']);

        // Execute the prepared statement to insert data into tb_scodes table
        if ($stmt->execute()) {
            // Redirect to success page
            if (!empty($successpath)) {
                header('Location: ' . $successpath);
            } else {
                header('Location: ' . $rbody['url']);
            }
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        if ($stmt->errno == 1062) {
            // Handle duplicate entry error here
            // For example, display an error message or redirect the user
            echo "Error: This email address is already registered.";
        } else {
            // Handle other errors
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
} else {
    /*Do something here if payment has not been made*/
    $type = $_GET['reference_1'];
    if ($type == 'parent') {
        $type = 4;
    } else {
        $type = 2;
    }
    
    $user_data = array(
        'u_name' => $rbody['reference_1'],
        'u_email' => $rbody['email'],
        'u_contact' => $rbody['mobile'],
        'userid' => $user_id,
        'u_pwd' => $hashed_password,
        'u_type' => $type,
    );
    
    // Check if connection was successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $subscription_data = array(
        'user_name' => $rbody['name'],
        'user_email' => $user_data['u_email'],
        'transaction_id' => $rbody['id'],
        'amount' => $rbody['amount'] / 100,
        'status' => 'failed',
        'userid' => $user_id, // Assign 'userid' if available, otherwise null
    );
    
    $stmt = $conn->prepare("INSERT INTO subscription (s_name, s_email, transaction_id, s_amount, s_status, s_start_date, s_end_date, subscriber_id) VALUES (?, ?, ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 MONTH), ?)");
    
    if ($stmt === false) {
        echo "Error: " . $conn->error;
        // exit();
    }
    
    $stmt->bind_param("sssssi", $subscription_data['user_name'], $subscription_data['user_email'], $subscription_data['transaction_id'], $subscription_data['amount'], $subscription_data['status'], $subscription_data['userid']);
    
    // Execute the SQL statement
    $stmt->execute();
    
    // Close the statement
    $stmt->close();
    
    // Redirect to the payment error page
    header('Location: ../../payment_error.php');
    


}

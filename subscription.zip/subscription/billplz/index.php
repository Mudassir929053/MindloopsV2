<!-- <form method="post" action="billplzpost.php">
    <input type="text" name='name' required value='Payer Name Here'><br>
    <input type="text" name='email' required value='PayerEmailHere@gmail.com'>
    <input type="text" name="mobile" value="60121234567">
    <input type="text" name="amount" value ="5430">
    <input type="text" name="reference_1_label" value="">
    <input type="text" name="reference_1" value="7">
    <input type="text" name="reference_2_label" value="">
    <input type="text" name="reference_2" value="7">
    <input type="text" name="description" value ="apa2">
    <input type="text" name="collection_id" value = "">
    <input type="submit">
</form> -->
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Payment trail</title>
</head>

<body>
    <div class="container">
        <div class="row">
            <form method="post" action="billplzpost.php">
                <div class="row">
                    <div class="col">
                        <label for="name">Payer Name</label>
                        <input type="text" class="form-control" id="name" name="name" required value="Payer Name Here">
                    </div>
                    <div class="col">
                        <label for="email">Email Address</label>
                         <input type="email" class="form-control" id="email" name="email" required value="PayerEmailHere@gmail.com">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="mobile" class="form-label">Mobile Number</label>
                        <input type="text" class="form-control" id="mobile" name="mobile" value="60121234567">
                    </div>
                    <div class="col">
                        <label for="amount" class="form-label">Amount</label>
                        <input type="text" class="form-control" id="amount" name="amount" value="5430">
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                    <label for="reference_2" class="form-label">Reference 2</label>
                        <input type="text" class="form-control" id="reference_2" name="reference_2" value="7">
                    </div>
                    <div class="col">
                        <label for="reference_1" class="form-label">Reference 1</label>
                        <input type="text" class="form-control" id="reference_1" name="reference_1" value="7">
                    </div>
                </div>
                
                <div class="row">
                    <div class="col">
                        <label for="description" class="form-label">Description</label>
                        <input type="text" class="form-control" id="description" name="description" value="apa2">
                    </div>
                    <div class="col ">
                        <label for="collection_id" class="form-label d-none">Collection ID</label>
                        <input type="text" class="form-control d-none" id="collection_id" name="collection_id">
                        <br>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>

            </form>

        </div>
    </div>


    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>